package com.example.lista_tareas_ESI;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

// Clase AdaptadorParaTarea que extiende de RecyclerView.Adapter
public class AdaptadorParaTarea extends RecyclerView.Adapter<AdaptadorParaTarea.ViewHolder> {

    // Lista de tareas para el adaptador
    private final ArrayList<Tarea> tareas;

    // Interfaz para manejar eventos de clic en elementos de la lista
    private OnItemClickListener onItemClickListener;

    // Definición de la interfaz OnItemClickListener
    public interface OnItemClickListener {
        void onItemClick(int position, Tarea tarea);
    }

    // Método para establecer el listener de clic en los elementos
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.onItemClickListener = listener;
    }

    // Constructor del adaptador con lista de tareas
    public AdaptadorParaTarea(ArrayList<Tarea> tareas) {
        this.tareas = tareas;
    }

    // Método para crear nuevos ViewHolders
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_layout, parent, false);
        return new ViewHolder(view);
    }

    // Método para enlazar datos con un ViewHolder
    @Override
    public void onBindViewHolder(@NonNull AdaptadorParaTarea.ViewHolder holder, int position) {
        Tarea tarea = tareas.get(position);
        String status = "pendiente";
        if (tarea.isCompletada()) {
            status = "completada";
        }

        // Enlazar los datos de la tarea a los componentes del ViewHolder
        holder.textTitulo.setText(tarea.getTitulo());
        holder.textDescripcion.setText(tarea.getDescripcion());
        holder.fechaLimite.setText(tarea.getFechaLimite());
        holder.completada.setText(status);

        // Configurar el listener para el clic en el elemento
        holder.itemView.setOnClickListener(view -> {
            if (onItemClickListener != null) {
                onItemClickListener.onItemClick(position, tarea);
            }
        });

    }

    // Método para obtener el número de elementos en el adaptador
    @Override
    public int getItemCount() {
        return tareas.size();
    }

    // Clase estática ViewHolder para gestionar las vistas de cada elemento
    public static class ViewHolder extends RecyclerView.ViewHolder {

        // Componentes de la interfaz para cada elemento
        private final TextView textTitulo, textDescripcion, fechaLimite, completada;

        // Constructor del ViewHolder para asociar los componentes
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textTitulo = itemView.findViewById(R.id.tituloTextView);
            textDescripcion = itemView.findViewById(R.id.descripcionTextView);
            fechaLimite = itemView.findViewById(R.id.fechaLimiteTextView);
            completada = itemView.findViewById(R.id.completadaTextView);

        }
    }
}
