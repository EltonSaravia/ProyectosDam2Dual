package com.example.lista_tareas_ESI;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.os.Parcelable;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

// Clase principal que extiende de AppCompatActivity
public class Main extends AppCompatActivity implements AdaptadorParaTarea.OnItemClickListener,
        Detalles_tareas.OnTareaDeletedListener, Modificar_Tarea.OnTareaModifiedListener, nuevaTarea.OnTareaAddedListener {

    ListaTarea listaTarea;
    nuevaTarea nuevaTarea;
    ArrayList<Tarea> listaTareas;
    AdaptadorParaTarea adapter;

    // Método onCreate para inicializar la actividad
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicialización de tareas y adaptador
        listaTareas = Tarea.obtenerTareasEjemplo();
        adapter = new AdaptadorParaTarea(listaTareas);
        listaTarea = new ListaTarea(adapter, listaTareas);
        nuevaTarea = new nuevaTarea();

        // Cargar el fragmento principal si la actividad se inicia por primera vez
        if (savedInstanceState == null) {
            loadFragment(listaTarea);
        }

        // Configuración del botón flotante para añadir nuevas tareas
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(v -> {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.fragmentContainer, new nuevaTarea());
            ft.addToBackStack(null);
            ft.commit();
        });
    }

    // Método para cargar un fragmento
    private void loadFragment(ListaTarea fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainer, fragment);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    // Manejo del evento de clic en un elemento de la lista
    @Override
    public void onItemClick(int position, Tarea tarea) {
        Detalles_tareas detallesTareas = new Detalles_tareas();

        // Pasar la tarea seleccionada al fragmento de detalles
        Bundle bundle = new Bundle();
        bundle.putParcelable("tarea", (Parcelable) tarea);
        bundle.putInt("position", position);
        detallesTareas.setArguments(bundle);

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentContainer, detallesTareas)
                .addToBackStack(null)
                .commit();
    }

    // Método para inflar el menú
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // Método para manejar la selección de ítems del menú
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.menu_lista_tareas) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.fragmentContainer, listaTarea).addToBackStack(null).commit();
        } else if (item.getItemId() == R.id.menu_aniadir_tarea) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.fragmentContainer, new nuevaTarea()).addToBackStack(null).commit();
        }

        return super.onOptionsItemSelected(item);
    }

    // Implementación de los métodos de los listener para actualizar el fragmento de la lista
    @Override
    public void onTareaDeleted(int position, Tarea t) {
        listaTarea.onTareaDeleted(position, t);
    }

    @Override
    public void onTareaModified(int position, Tarea t) {
        listaTarea.onTareaModified(position, t);
    }

    @Override
    public void onTareaAdded(Tarea tarea) {
        listaTarea.onTareaAdded(tarea);
    }
}
