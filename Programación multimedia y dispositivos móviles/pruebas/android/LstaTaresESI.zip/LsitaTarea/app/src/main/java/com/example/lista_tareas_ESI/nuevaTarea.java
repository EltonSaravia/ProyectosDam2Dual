package com.example.lista_tareas_ESI;

import android.content.Context;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import java.text.*;
import java.util.*;

public class nuevaTarea extends Fragment {

    private EditText editFechaLimite;
    Button btnCancel;
    Button btnOk;
    // Variable de instancia para gestionar el listener de tareas añadidas
    private OnTareaAddedListener onTareaAddedListener;

    // Método para establecer el listener de tareas añadidas
    public void setOnTareaAddedListener(OnTareaAddedListener listener) {
        this.onTareaAddedListener = listener;
    }

    // Constructor vacío requerido (usual en fragmentos)
    public nuevaTarea() {
        // Required empty public constructor
    }

    // Método estático para crear una nueva instancia del fragmento
    public static nuevaTarea newInstance() {
        return new nuevaTarea();
    }

    // Método para crear la vista del fragmento
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflar la interfaz de usuario para este fragmento
        View view = inflater.inflate(R.layout.nueva_tarea, container, false);
        EditText editTitulo = view.findViewById(R.id.cambiarTitulo);
        EditText editDesc = view.findViewById(R.id.cambiarDescripcion);
        editFechaLimite = view.findViewById(R.id.editFechaLimite);
        btnOk = view.findViewById(R.id.btnOkEdit);
        btnCancel = view.findViewById(R.id.btnCancelar);
// Configurar listener para el botón guardar
        btnOk.setOnClickListener(v -> {
            // Obtener y procesar la información de los campos de texto
            String titulo = editTitulo.getText().toString();
            String descripcion = editDesc.getText().toString();
            String strFecha = editFechaLimite.getText().toString();
            // Formatear y validar la fecha
            SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            format.setLenient(false);
            Date fechaLimite;
            try {
                // Intentar parsear la fecha
                fechaLimite = format.parse(strFecha);
                Date now = new Date();
                // Verificar si la fecha es posterior a la actual
                if (!fechaLimite.after(now)) {
                    // Si la fecha es antes de la actual, establece para mañana.
                    // Si no lo es, establecer la fecha para mañana
                    Calendar c = Calendar.getInstance();
                    c.add(Calendar.DAY_OF_YEAR, 1);
                    fechaLimite = c.getTime();
                    Toast.makeText(getActivity(), "Formato de fecha no válido o anterior a la actual, se ha establecido para mañana.", Toast.LENGTH_LONG).show();
                }
            } catch (ParseException e) {
                // Si la fecha no es correcta o no se ha introducido, pon la de mañana.
                Calendar c = Calendar.getInstance();
                c.add(Calendar.DAY_OF_YEAR, 1);
                fechaLimite = c.getTime();
                Toast.makeText(getActivity(), "Formato de fecha no válido o anterior a la actual, se ha establecido para mañana.", Toast.LENGTH_LONG).show();
            }
            // Actualizar campo de fecha con el valor procesado
            strFecha = format.format(fechaLimite);
            editFechaLimite.setText(strFecha);

            // Procede con la creación de la Tarea
            if (onTareaAddedListener != null) {
                Tarea newTarea = new Tarea(titulo, descripcion, strFecha, false);
                onTareaAddedListener.onTareaAdded(newTarea);
            }

            // Cerrar el fragmento actual
            getParentFragmentManager().popBackStack();
        });
        // Configurar listener para el botón Cancelar
        btnCancel.setOnClickListener(v -> {
            // Cerrar el fragmento actual
            getParentFragmentManager().popBackStack();
        });

        return view;
    }

    public interface OnTareaAddedListener {
        // Interfaz para el listener de tareas añadidas
        void onTareaAdded(Tarea tarea);
    }
    // Método que se llama cuando el fragmento se adjunta a su contexto
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof OnTareaAddedListener) {
            onTareaAddedListener = (OnTareaAddedListener) context;
        } else {
            throw new RuntimeException(context.toString() + "Error al añadirb ");
        }
    }
}
