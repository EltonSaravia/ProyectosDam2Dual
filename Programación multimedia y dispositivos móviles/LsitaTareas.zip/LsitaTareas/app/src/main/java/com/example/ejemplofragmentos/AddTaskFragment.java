package com.example.ejemplofragmentos;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class AddTaskFragment extends Fragment {

    private EditText titleEditText, descriptionEditText, dueDateEditText;
    private Button saveButton;
    private TaskListener listener;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof TaskListener) {
            listener = (TaskListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement TaskListener");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_task, container, false);

        titleEditText = view.findViewById(R.id.titleEditText);
        descriptionEditText = view.findViewById(R.id.descriptionEditText);
        dueDateEditText = view.findViewById(R.id.dueDateEditText);
        saveButton = view.findViewById(R.id.saveButton);
        onAttach(getContext());
        saveButton.setOnClickListener(v -> {
            String title = titleEditText.getText().toString().trim();
            String description = descriptionEditText.getText().toString().trim();
            String dueDate = dueDateEditText.getText().toString().trim();

            // Validar que los campos no están vacíos antes de crear la tarea
            if (!title.isEmpty() && !description.isEmpty() && !dueDate.isEmpty()) {
                // Crear un objeto Task. Asegúrate de que tu objeto Task pueda manejar todos los parámetros.
                Task newTask = new Task(title, description, dueDate, false); // false para indicar que la tarea está pendiente
                MainActivity.taskList.add(newTask);

                // Limpiar los campos o cerrar el fragmento si es necesario
                titleEditText.setText("");
                descriptionEditText.setText("");
                dueDateEditText.setText("");

                FragmentManager fm = getActivity().getSupportFragmentManager();
                fm.popBackStack();
            } else {
                // Mostrar un mensaje de error o realizar alguna acción de validación
            }
        });

        return view;
    }

    // Puedes crear un método que limpie los campos o maneje el cierre del fragmento si es necesario
}
