package com.example.ejemplofragmentos;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerVew extends Fragment {

    private ArrayList<Persona> datos = new ArrayList<>();

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflar el layout del fragmento
        View rootView = inflater.inflate(R.layout.activity_mainrecycle, container, false);

        // Generamos una lista de personas
        datos = Persona.generarLista(25);

        // Recuperamos la RV del layout inflado
        RecyclerView rvListaPersonas = rootView.findViewById(R.id.rvLista);

        // Tamaño fijo
        rvListaPersonas.setHasFixedSize(true);

        // Indicamos un layout al RV
        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        rvListaPersonas.setLayoutManager(llm);

        // Añadir la separación
        DividerItemDecoration separacion = new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL);
        rvListaPersonas.addItemDecoration(separacion);

        // Creamos el adaptador
        Adaptador aa = new Adaptador(datos);

        // Asociamos el adaptador a la lista
        rvListaPersonas.setAdapter(aa);

        return rootView;
    }

    private void setContentView(int activityMain) {
    }

    @NonNull
    @Override
    public CreationExtras getDefaultViewModelCreationExtras() {
        return super.getDefaultViewModelCreationExtras();
    }
}
