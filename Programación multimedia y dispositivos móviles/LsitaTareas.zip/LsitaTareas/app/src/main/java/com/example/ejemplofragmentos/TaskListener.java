package com.example.ejemplofragmentos;

import android.view.View;

public interface TaskListener {
    void onTaskAdded(Task task);
    void onTaskSelected(View v, int pos);
    void onTaskSelected(Task task);

}