package com.example.ejemplofragmentos;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, TaskListener, TaskListFragment.OnTaskInteractionListener {

    private DrawerLayout drawerLayout;
    public static List<Task> taskList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Task task1 = new Task("Tarea 1", "Descripción 1", "01/01/2024", false);
        Task task2 = new Task("Tarea 2", "Descripción 2", "02/02/2024", false);
        Task task3 = new Task("Tarea 3", "Descripción 3", "03/03/2024", false);

        // Añadir tareas a la lista
        taskList.add(task1);
        taskList.add(task2);
        taskList.add(task3);

        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close
        );
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        if (savedInstanceState == null) {
            navigationView.setCheckedItem(R.id.nav_task_list);
            showFragment(new TaskListFragment());
        }

        FloatingActionButton fab = findViewById(R.id.add_task_fab);
        fab.setOnClickListener(view -> showFragment(new AddTaskFragment()));
    }

    private void showFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_task_list) {
            showFragment(new TaskListFragment());
        } else if (id == R.id.nav_add_task) {
            showFragment(new AddTaskFragment());
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            if (getSupportFragmentManager().getBackStackEntryCount() > 1) {
                getSupportFragmentManager().popBackStack();
            } else {
                super.onBackPressed();
            }
        }
    }

    // Método para manejar la adición de una tarea desde AddTaskFragment
    public void onTaskAdded(Task task) {
        TaskListFragment taskListFragment = findTaskListFragment();
        if (taskListFragment != null) {
            taskListFragment.addTask(task);
        }
    }

    @Override
    public void onTaskSelected(View v, int pos) {

    }

    @Override
    public void onTaskSelected(Task task) {
        // Crear una instancia de TaskDetailFragment
        TaskDetailFragment taskDetailFragment = new TaskDetailFragment();

        // Pasar los datos de la tarea al fragmento
        Bundle args = new Bundle();
        args.putSerializable("selectedTask", task);
        taskDetailFragment.setArguments(args);

        // Reemplazar el fragmento actual por TaskDetailFragment
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, taskDetailFragment)
                .addToBackStack(null)
                .commit();
    }

    public void onTaskSelected(Task task, int position) {
        TaskDetailFragment taskDetailFragment = new TaskDetailFragment();

        Bundle args = new Bundle();
        args.putSerializable("selectedTask", task);
        args.putInt("taskIndex", position); // Pasar el índice de la tarea
        taskDetailFragment.setArguments(args);

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, taskDetailFragment)
                .addToBackStack(null)
                .commit();
    }
    // Método para buscar la instancia actual de TaskListFragment
    private TaskListFragment findTaskListFragment() {
        List<Fragment> fragments = getSupportFragmentManager().getFragments();
        for (Fragment fragment : fragments) {
            if (fragment instanceof TaskListFragment) {
                return (TaskListFragment) fragment;
            }
        }
        return null;
    }

    public void deleteTask(Task task) {
        int index = -1;
        for (int i = 0; i < taskList.size(); i++) {
            if (taskList.get(i).equals(task)) {
                index = i;
                break;
            }
        }

        if (index != -1) {
            taskList.remove(index);
            TaskListFragment fragment = findTaskListFragment();
            if (fragment != null) {
                fragment.notifyTaskRemoved(index);
            }
        }
    }

    public void deleteTaskAtIndex(int index) {
        if (index >= 0 && index < taskList.size()) {
            taskList.remove(index);
            TaskListFragment fragment = findTaskListFragment();
            if (fragment != null) {
                fragment.notifyTaskRemoved(index);
            }
        }
    }

}
