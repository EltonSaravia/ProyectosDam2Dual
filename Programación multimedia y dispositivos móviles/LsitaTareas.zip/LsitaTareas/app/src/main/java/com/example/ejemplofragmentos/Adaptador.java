package com.example.ejemplofragmentos;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ejemplofragmentos.R;

import java.util.ArrayList;

public class Adaptador extends RecyclerView.Adapter<Adaptador.ViewHolder> {

    //El adaptador recibe un ArrayList, crea un ViewHolder y los enlaza
    private final ArrayList<Persona> listaPersonas; //los datos a adaptar
    public Adaptador(ArrayList<Persona> listaPersonas){
        this.listaPersonas = listaPersonas;
    }


    //Hay que implementar los métodos oncreate, onbind, getitemcount

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //infla la vista, crea un viewHolder y lo devuelve
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.filas,parent,false);
        return  new Adaptador.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        //adaptamos los datos a la vista
      holder.tvNombre.setText(listaPersonas.get(position).getNombre());
      holder.tvEmpresa.setText(listaPersonas.get(position).getEmpresa());
      holder.tvCargo.setText(listaPersonas.get(position).getCargo());

    }

    @Override
    public int getItemCount() {
        return listaPersonas.size();
    }

    //La clase interna crea el viewholder con una view
    public static class ViewHolder extends RecyclerView.ViewHolder {

        private final TextView tvNombre,tvCargo,tvEmpresa;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombre = itemView.findViewById(R.id.textView);
            tvCargo = itemView.findViewById(R.id.textView2);
            tvEmpresa = itemView.findViewById(R.id.textView3);
        }

    }//ViewHolder
}
