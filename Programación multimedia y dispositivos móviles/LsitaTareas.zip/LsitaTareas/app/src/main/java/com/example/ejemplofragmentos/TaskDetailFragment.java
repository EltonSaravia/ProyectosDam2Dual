package com.example.ejemplofragmentos;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class TaskDetailFragment extends Fragment {

    private TextView titleTextView, descriptionTextView, dueDateTextView;
    private Button deleteButton;
    private Task task;
    private int taskIndex;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_task_detail, container, false);

        titleTextView = view.findViewById(R.id.titleTextView);
        descriptionTextView = view.findViewById(R.id.descriptionTextView);
        dueDateTextView = view.findViewById(R.id.dueDateTextView);


        deleteButton = view.findViewById(R.id.deleteButton);

        Bundle bundle = getArguments();
        if (bundle != null) {
            task = (Task) bundle.getSerializable("selectedTask");
            taskIndex = bundle.getInt("taskIndex", -1); // Obtener el índice
        }

        deleteButton.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity && taskIndex != -1) {
                ((MainActivity) getActivity()).deleteTaskAtIndex(taskIndex);
                // Regresar a la lista de tareas
                getActivity().getSupportFragmentManager().popBackStack();
            }
        });




        return view;
    }

    private void deleteTask() {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).deleteTask(task);
        }
    }
}
