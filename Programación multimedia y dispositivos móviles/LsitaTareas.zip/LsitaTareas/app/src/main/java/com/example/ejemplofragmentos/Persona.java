package com.example.ejemplofragmentos;

import java.util.ArrayList;

public class Persona {

    private String nombre, cargo, empresa;

    public Persona(String nombre, String cargo, String empresa) {
        this.nombre = nombre;
        this.cargo = cargo;
        this.empresa = empresa;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCargo() {
        return cargo;
    }

    public String getEmpresa() {
        return empresa;
    }

    public static ArrayList generarLista(int n){
        ArrayList<Persona> lista = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            Persona p = new Persona("Persona " + i,"Cargo " + i, "Empresa " + i);
            lista.add(p);
        }
        return lista;
    }
}
