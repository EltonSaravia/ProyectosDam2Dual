package com.example.ejemplofragmentos;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class TaskListFragment extends Fragment implements TaskListener {

    private RecyclerView recyclerView;
    private TaskAdapter adapter;

    OnTaskInteractionListener mCallback;

    // Interfaz para comunicarse con la actividad
    public interface OnTaskInteractionListener {
        void onTaskSelected(Task task);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        // Asegúrate de que la actividad contenedora haya implementado la interfaz de callback
        try {
            mCallback = (OnTaskInteractionListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement OnTaskInteractionListener");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_task_list, container, false);

        recyclerView = view.findViewById(R.id.recycler_view);
        LinearLayoutManager lm = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(lm);
        DividerItemDecoration itemDecoration = new DividerItemDecoration(getContext(), DividerItemDecoration.VERTICAL);
        recyclerView.addItemDecoration(itemDecoration);

        // Modificación aquí: Inicialización de TaskAdapter con 'this' como TaskListener
        adapter = new TaskAdapter(MainActivity.taskList, this);
        recyclerView.setAdapter(adapter);



        return view;
    }
    public void notifyTaskRemoved(int position) {
        if (adapter != null) {
            adapter.notifyItemRemoved(position);
        }
    }

    public void addTask(Task task) {
        if(task != null) {
            MainActivity.taskList.add(task);
            adapter.notifyItemInserted(MainActivity.taskList.size() - 1);
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onTaskAdded(Task task) {
        // Implementación según sea necesario
    }

    @Override
    public void onTaskSelected(View v, int pos) {
        // Obtener la tarea seleccionada
        Task selectedTask = MainActivity.taskList.get(pos);
        // Llamar al método de la interfaz
        mCallback.onTaskSelected(selectedTask);
    }

    @Override
    public void onTaskSelected(Task task) {
        // Lógica para abrir TaskDetailFragment
        Bundle bundle = new Bundle();
        bundle.putSerializable("task", task);

        TaskDetailFragment taskDetailFragment = new TaskDetailFragment();
        taskDetailFragment.setArguments(bundle);

        getParentFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, taskDetailFragment)
                .addToBackStack(null)
                .commit();
    }

    // ...otros métodos que puedas necesitar...
}
